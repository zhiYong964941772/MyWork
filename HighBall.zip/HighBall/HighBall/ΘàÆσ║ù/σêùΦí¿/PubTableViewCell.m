//
//  PubTableViewCell.m
//  HighBall
//
//  Created by imac on 15-7-3.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import "PubTableViewCell.h"

@implementation PubTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

}

@end
