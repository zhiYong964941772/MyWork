//
//  PayOrderTableViewController.h
//  HighBall
//
//  Created by imac on 15-7-6.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PayOrderTableViewController : UITableViewController

@end
