//
//  FillOutOrderViewController.h
//  HighBall
//
//  Created by imac on 15-7-4.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FillOutOrderViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *numberSpece;

@end
