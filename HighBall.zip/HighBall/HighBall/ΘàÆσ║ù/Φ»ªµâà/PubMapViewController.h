//
//  PubMapViewController.h
//  HighBall
//
//  Created by imac on 15-7-7.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BaiduMapAPI/BMapKit.h>
#import <MapKit/MapKit.h>

@interface PubMapViewController : UIViewController<BMKMapViewDelegate,UIAlertViewDelegate>

@end
