//
//  YMNumbers.h
//  HighBall
//
//  Created by imac on 15-7-7.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YMNumbers : UIView<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)NSArray *numbersArr;
@end
