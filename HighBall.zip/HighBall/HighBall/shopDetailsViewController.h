//
//  shopDetailsViewController.h
//  HighBall
//
//  Created by imac on 15-8-1.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface shopDetailsViewController : UIViewController

@end
