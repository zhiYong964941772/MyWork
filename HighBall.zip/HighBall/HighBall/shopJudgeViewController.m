//
//  shopJudgeViewController.m
//  HighBall
//
//  Created by imac on 15-8-4.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import "shopJudgeViewController.h"
#import "UIView+Extension.h"
@interface shopJudgeViewController ()

@end

@implementation shopJudgeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadViewWithNewView];
    self.view.backgroundColor = [UIColor clearColor];
}
- (void)loadViewWithNewView{
    
    
    
    
    
    
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
   
}


@end
