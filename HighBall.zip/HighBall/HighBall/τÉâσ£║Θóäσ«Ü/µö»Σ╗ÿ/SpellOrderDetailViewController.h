//
//  SpellOrderDetailViewController.h
//  HighBall
//
//  Created by imac on 15-7-8.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SpellOrderDetailViewController : UIViewController
//传过来的按钮状态码
@property(nonatomic,strong)NSString *number;

@end
