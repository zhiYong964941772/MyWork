//
//  OrderTableViewController.h
//  HighBall
//
//  Created by imac on 15-5-14.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderTableViewController : UITableViewController

@end
