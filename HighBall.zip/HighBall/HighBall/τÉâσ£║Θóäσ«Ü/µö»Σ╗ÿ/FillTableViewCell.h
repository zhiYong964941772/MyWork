//
//  FillTableViewCell.h
//  HighBall
//
//  Created by imac on 15-6-6.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FillTableViewCell : UITableViewCell
@property(nonatomic,strong)NSString *number;
@end
