//
//  ConcludSpellTableViewController.h
//  HighBall
//
//  Created by imac on 15-4-25.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConcludSpellTableViewController : UITableViewController
@property(nonatomic,copy)NSString *city;
@property(nonatomic,copy)NSString *date;
@property(nonatomic,copy)NSString *ballSpellName;
@end
