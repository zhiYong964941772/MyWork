//
//  BallSpellNameTableViewController.h
//  HighBall
//
//  Created by imac on 15-5-4.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BallSpellNameTableViewController : UITableViewController<UISearchBarDelegate>

@end
