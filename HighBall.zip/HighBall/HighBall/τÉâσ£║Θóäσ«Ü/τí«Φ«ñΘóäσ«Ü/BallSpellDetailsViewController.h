//
//  BallSpellDetailsViewController.h
//  HighBall
//
//  Created by imac on 15-4-25.
//  Copyright (c) 2015年 YM. All rights reserved.
//

/*
 球场的具体信息
 */

#import <UIKit/UIKit.h>
#import "CourselInfo.h"

@interface BallSpellDetailsViewController : UIViewController
@property(nonatomic,copy)NSString *courselID;
@end
