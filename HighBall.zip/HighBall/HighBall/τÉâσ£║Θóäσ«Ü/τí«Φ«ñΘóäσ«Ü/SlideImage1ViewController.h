//
//  SlideImage1ViewController.h
//  HighBall
//
//  Created by imac on 15-6-26.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SlideImage1ViewController : UIViewController
@property(nonatomic,strong)NSArray *imageArr;
@end
