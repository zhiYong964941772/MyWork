//
//  shopJudgeTableView.h
//  HighBall
//
//  Created by imac on 15-8-5.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface shopJudgeTableView : UITableViewController

@end
