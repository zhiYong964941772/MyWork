//
//  judgeTableViewController.h
//  HighBall
//
//  Created by imac on 15-8-4.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface judgeTableViewController : UITableViewController

@end
