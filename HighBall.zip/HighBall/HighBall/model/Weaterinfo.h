//
//  Weaterinfo.h
//  TableViewAlert
//
//  Created by imac on 15-5-23.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Weaterinfo : NSObject
@property(nonatomic,copy)NSString *desc;
@property(nonatomic,strong)NSMutableArray *weterArr;
@end
