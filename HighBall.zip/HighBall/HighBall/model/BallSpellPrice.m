//
//  BallSpellPrice.m
//  HighBall
//
//  Created by imac on 15-4-28.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import "BallSpellPrice.h"

@implementation BallSpellPrice

@end
