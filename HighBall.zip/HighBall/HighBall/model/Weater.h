//
//  Weater.h
//  TableViewAlert
//
//  Created by imac on 15-5-22.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Weater : NSObject
@property(nonatomic,copy)NSString *date;
@property(nonatomic,copy)NSString *high;
@property(nonatomic,copy)NSString *type;
@property(nonatomic,copy)NSString *low;



@end
