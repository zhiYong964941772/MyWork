//
//  Citie.h
//  HighBall
//
//  Created by imac on 15-5-21.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Citie : NSObject

@property(nonatomic,copy)NSString *cityId;//城市ID
@property(nonatomic,copy)NSString *cityName;//城市名称

@end
