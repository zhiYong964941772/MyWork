//
//  BallSpellInfo.m
//  HighBall
//
//  Created by imac on 15-4-25.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import "BallSpellInfo.h"

@implementation BallSpellInfo

@end
