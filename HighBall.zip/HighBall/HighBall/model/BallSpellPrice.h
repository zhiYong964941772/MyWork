//
//  BallSpellPrice.h
//  HighBall
//
//  Created by imac on 15-4-28.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BallSpellPrice : NSObject
@property(nonatomic,copy)NSString *date;
@property(nonatomic,copy)NSString *price;
@end
