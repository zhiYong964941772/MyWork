//
//  Weaterinfo.m
//  TableViewAlert
//
//  Created by imac on 15-5-23.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import "Weaterinfo.h"

@implementation Weaterinfo

-(instancetype)init
{
    self=[super init];
    if (self) {
        self.weterArr=[NSMutableArray array];
    }
    return self;
}

@end
