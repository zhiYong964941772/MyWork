//
//  shopTableViewCell.h
//  HighBall
//
//  Created by imac on 15-7-31.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface shopTableViewCell : UITableViewCell

@end
