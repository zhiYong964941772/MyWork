//
//  BallNavigationController.h
//  HighBall
//
//  Created by imac on 15-7-29.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BallNavigationController : UINavigationController

@end
