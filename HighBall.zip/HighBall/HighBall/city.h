//
//  city.h
//  HighBall
//
//  Created by imac on 15-7-23.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface city : NSObject

+ (NSArray *)allCity;
@end
