//
//  parameterTableViewCell.h
//  HighBall
//
//  Created by imac on 15-8-4.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface parameterTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *Mainlabel;
@property (weak, nonatomic) IBOutlet UILabel *secondlabel;

@end
