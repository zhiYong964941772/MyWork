//
//  cityCell.h
//  HighBall
//
//  Created by imac on 15-7-23.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cityCell : UICollectionViewCell
@property(nonatomic,strong)UIImageView *bgImageView;
@property(nonatomic,strong)UILabel *label;

@end
