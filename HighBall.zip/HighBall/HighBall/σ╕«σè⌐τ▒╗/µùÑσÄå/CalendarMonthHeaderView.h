//
//  ETIMonthHeaderView.h
//  CalendarIOS7
//

#import <UIKit/UIKit.h>

@interface CalendarMonthHeaderView : UICollectionReusableView

@property (weak, nonatomic) UILabel *masterLabel;

@end
