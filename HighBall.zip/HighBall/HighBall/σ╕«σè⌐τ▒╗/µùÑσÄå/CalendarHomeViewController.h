//
//  CalendarHomeViewController.h
//  Calendar
//

#import <UIKit/UIKit.h>
#import "CalendarViewController.h"


@interface CalendarHomeViewController : CalendarViewController

- (void)setAirPlaneToDay:(int)day ToDateforString:(NSString *)todate;

@end
