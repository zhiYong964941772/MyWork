//
//  ETIAgendaMonthCollectionViewLayout.h
//  CalendarIOS7
//

#import <UIKit/UIKit.h>

@interface CalendarMonthCollectionViewLayout : UICollectionViewFlowLayout

@end
