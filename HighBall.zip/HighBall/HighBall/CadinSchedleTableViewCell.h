//
//  CadinSchedleTableViewCell.h
//  HighBall
//
//  Created by imac on 15-7-10.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CadinSchedleTableViewCell : UITableViewCell
- (IBAction)cadinDaileAction:(id)sender;

@end
