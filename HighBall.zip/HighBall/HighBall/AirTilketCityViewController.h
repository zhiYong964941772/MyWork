//
//  AirTilketCityViewController.h
//  HighBall
//
//  Created by imac on 15-7-23.
//  Copyright (c) 2015年 YM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AirTilketCityViewController : UIViewController
@property (nonatomic,strong)UILabel *label;
@end
